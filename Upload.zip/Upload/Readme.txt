ARC_SL: Association rule-based classification with soft labels
Copyright (C) 2021-2022, by Lianmeng Jiao (jiaolianmeng@nwpu.edu.cn)

Please use the main function ARC_SL.m to train and test datesets.